npm init -y
npm install express mongoose multer dotenv
node server.js